# Budget Tracker Starter Kit - Group 11

This zip is for Group 11: Monthly Report.

## What is inside

- snippets/: the scattered Python pieces to rebuild main.py.
- sample_data/budget_data.json: sample data for testing.
- README_NUDGE.md: gentle hints for arranging the snippets.
- group-11-feature-pack.pdf: your group's feature mission PDF.
- group-11-feature-pack.md: the same mission as text.

Do not use another group's zip. Each group has a different feature mission.
