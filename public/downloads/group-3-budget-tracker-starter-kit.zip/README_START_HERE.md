# Budget Tracker Starter Kit - Group 3

This zip is for Group 3: Time Summaries.

## What is inside

- snippets/: the scattered Python pieces to rebuild main.py.
- sample_data/budget_data.json: sample data for testing.
- README_NUDGE.md: gentle hints for arranging the snippets.
- group-3-feature-pack.pdf: your group's feature mission PDF.
- group-3-feature-pack.md: the same mission as text.

Do not use another group's zip. Each group has a different feature mission.
